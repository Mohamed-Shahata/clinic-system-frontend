import { NextResponse, type NextRequest } from 'next/server';
import { cookies } from 'next/headers';
import { getBackendBaseUrl } from '@/lib/backend-url';

async function getToken() {
  const jar = await cookies();
  return jar.get('access_token')?.value ?? null;
}

export async function POST(request: NextRequest) {
  const token = await getToken();
  if (!token) return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });

  const body = await request.json();
  const backend = getBackendBaseUrl();

  // body.code means confirm step, otherwise request step
  const endpoint = body.code
    ? `${backend}/api/auth/email-change/confirm`
    : `${backend}/api/auth/email-change/request`;

  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(body),
    cache: 'no-store',
  }).catch(() => null);

  if (!res) {
    return NextResponse.json({ message: 'Cannot reach API server' }, { status: 502 });
  }

  const data = await res.json().catch(() => ({}));
  return NextResponse.json(data, { status: res.status });
}
